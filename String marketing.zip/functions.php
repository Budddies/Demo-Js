<?php

// Defines
define('FL_CHILD_THEME_DIR', get_stylesheet_directory());
define('FL_CHILD_THEME_URL', get_stylesheet_directory_uri());

// Classes
require_once 'classes/class-fl-child-theme.php';

// Actions
add_action('wp_enqueue_scripts', 'FLChildTheme::enqueue_scripts', 1000);

//FUNCTIONALITY FIXES OR ADDITIONS

//Embed Page Builder shortcode into a text widget
add_filter('widget_text', 'do_shortcode');

//Change the Customizer color palette presets
add_action('customize_controls_print_footer_scripts', function () {

?>
  <script>
    jQuery(document).ready(function($) {

      $('.wp-picker-container').iris({
        mode: 'hsl',
        controls: {
          horiz: 'h', // square horizontal displays hue
          vert: 's', // square vertical displays saturdation
          strip: 'l' // slider displays lightness
        },
        palettes: ['#BDE337', '#7AB543', '#214322', '#2E987C', '#DDDDDD', '#F2F2F2', '#761706', '#CA1B3A', '#FFFFFF', '#000000', ]
      })
    });
  </script>
<?php

});

//Add color presets for Page Builder
function my_builder_color_presets($colors)
{
  $colors[] = 'BDE337';
  $colors[] = '7AB543';
  $colors[] = '214322';
  $colors[] = '2E987C';
  $colors[] = 'DDDDDD';
  $colors[] = 'F2F2F2';
  $colors[] = '761706';
  $colors[] = 'CA1B3A';
  $colors[] = 'FFFFFF';
  $colors[] = '000000';
  return $colors;
}

add_filter('fl_builder_color_presets', 'my_builder_color_presets');

// Modify the recovery mode email address.
add_filter('recovery_mode_email', function ($email_data) {
  $email_data['to'] = 'support@stringmarketing.com';
  return $email_data;
});

// Enable MailChimp double opt-ins.
add_filter('fl_builder_mailchimp_double_option', '__return_true');

// Replace WordPress login logo with String Marketing login logo
function custom_login_page()
{ ?>
  <style type="text/css">
    /* Define login page background color - whitesmoke */
    body.login {
      background-color: #f8f8f8;
    }

    /* Define login logo image size - 300 X 105 */
    body.login div#login h1 a {
      background-image: url('https://stringmarketing.com/wp-content/uploads/2019/04/String_identity_R1-300x105.png');
      height: 105px;
      width: 300px;
      background-size: 300px 105px;
      background-repeat: no-repeat;
    }
  </style>
<?php
}
add_action('login_enqueue_scripts', 'custom_login_page');

//Disable email notifications for automatic core updates
add_filter('auto_core_update_send_email', 'wpb_stop_auto_update_emails', 10, 4);

function wpb_stop_update_emails($send, $type, $core_update, $result)
{
  if (!empty($type) && $type == 'success') {
    return false;
  }
  return true;
}

//Disable email notifications for automatic plugin updates
add_filter('auto_plugin_update_send_email', '__return_false');

//Disable email notifications for automatic theme updates
add_filter('auto_theme_update_send_email', '__return_false');
/**
 * Fonts
 * 
 * */

function my_bb_custom_fonts($system_fonts)
{

  $system_fonts['Gill Sans'] = array(
    'fallback' => 'Verdana, Arial, sans-serif',
    'weights' => array(
      '300',
      '400',
      '600',
    ),
  );

  $system_fonts['Gelasio'] = array(
    'fallback' => 'Verdana, Arial, sans-serif',
    'weights' => array(
      '400',
      '500',
      '600',
    ),
  );

  return $system_fonts;
}
//Add to Beaver Builder Theme Customizer
add_filter('fl_theme_system_fonts', 'my_bb_custom_fonts');
//Add to Beaver Builder modules
add_filter('fl_builder_font_families_system', 'my_bb_custom_fonts');
